Native GTK3 port of VICE
========================

See the files in doc/building about Gtk3.

(We really should delete this file)
