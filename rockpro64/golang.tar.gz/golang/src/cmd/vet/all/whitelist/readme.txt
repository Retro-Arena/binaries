This directory contains whitelists for vet complaints about the standard library and commands.
They are line-based and unordered, although counts of duplicated lines matter.
Each line matches vet's output, except that line numbers are removed to avoid churn.
There are also os-, arch-, and bitwidth-specific whitelists.
