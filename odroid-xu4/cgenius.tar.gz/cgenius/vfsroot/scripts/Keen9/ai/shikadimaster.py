def moreAgressive():
    # Is he more agressive?
    return True

