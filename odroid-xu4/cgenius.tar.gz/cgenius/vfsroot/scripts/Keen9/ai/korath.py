def isStunnableWithPogo():
    # Can Keen stun the enemy with pogo alone?
    return True


def isInvincible():
    # isInvincible. Shots never kill it
    return True


def willNeverStop():
    # willNeverStop. Robo red will continue chasing and shoot wherever required
    return True

