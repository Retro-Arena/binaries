def alternateShoot():
    # Will the foe shoot a different shot (Keen 9 - Cybloog)
    return True


def isInvincible():
    # isInvincible. Shots never kill it
    return True


def willNeverStop():
    # willNeverStop. Robo red will continue chasing and shoot wherever required
    return True

def mayJiggle():
    # Robored usually when shooting. Cybloogs do not
    return False



