def healthPoints():
    # Number of hit points before enemy is stunned
    return 3

def mayShoot():
    # Number of hit points before enemy is stunned
    return True

def screamAfterShoot():
    # Number of hit points before enemy is stunned
    return False

def allowClimbing():
    # Yeties cannot climp poles
    return False

def walkSound():
    return 0
