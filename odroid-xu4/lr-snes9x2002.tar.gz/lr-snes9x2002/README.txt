------------------------------------------------------------------------------
Stuff that I might fix:

* SA-1 and SuperFX games are slow, could use some optimization.
