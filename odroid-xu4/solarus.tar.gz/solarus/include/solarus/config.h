#define HAVE_MKSTEMP
#define HAVE_UNISTD_H

