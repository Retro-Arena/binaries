**bullets.json** and **guns.json**: definitions for bullets and guns used in game. See https://github.com/cxong/cdogs-sdl/wiki/Custom-Weapons
